<?php

namespace Vehica\Widgets\Partials\Gallery;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Class BaseGalleryElement
 * @package Vehica\Widgets\Partials\Gallery
 */
class BaseGalleryWidget
{
    const GALLERY_FIELD = 'vehica_gallery_field';

}